# Multi-User Socket Chat App

A multi-client chat application built with Python TCP sockets and threads. One server handles many clients at the same time.

## Features
- Multi-threaded server (one thread per client)
- Unique nicknames with validation
- Public broadcast chat and private messages
- Join and leave notifications
- Commands: `/list`, `/msg <user> <text>`, `/help`, `/quit`
- Server-side activity log (`chat.log`)
- Thread-safe shared state using a lock

## Run it
Requires Python 3.8+. No extra packages.

Start the server:
```bash
python server.py --port 5000
```

Open one or more terminals and connect clients:
```bash
python client.py --host 127.0.0.1 --port 5000
```

To chat across devices on the same network, run the server on one machine and use its local IP as `--host` in the clients.

## How it works
- The protocol is plain text, one message per line (newline-delimited), over TCP.
- The server accepts connections in a loop and starts a thread for each client.
- A shared dictionary maps nicknames to sockets, protected by a `threading.Lock`.
- The client uses one thread to print incoming messages while the main thread reads keyboard input.

## What I learned
- TCP client-server architecture and the socket lifecycle (bind, listen, accept, connect)
- Message framing over a byte stream
- Concurrency problems such as race conditions, and how locks prevent them
- Handling disconnects and cleanup

## Ideas to extend
- Chat rooms or channels
- Message encryption with TLS (`ssl` module)
- A GUI client with Tkinter
- Saving chat history to a database
