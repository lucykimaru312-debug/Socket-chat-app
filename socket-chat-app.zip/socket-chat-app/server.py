"""Multi-client TCP chat server.

Each client runs in its own thread. Messages are newline-delimited text.
Supports nicknames, broadcast, private messages, user list and logging.
"""
import argparse
import logging
import socket
import threading

clients = {}  # nickname -> socket
lock = threading.Lock()

HELP = (
    "Commands:\n"
    "  /list              show online users\n"
    "  /msg <user> <text> send a private message\n"
    "  /help              show this help\n"
    "  /quit              leave the chat"
)


def send(sock, text):
    try:
        sock.sendall((text + "\n").encode("utf-8"))
    except OSError:
        pass


def broadcast(text, exclude=None):
    with lock:
        targets = [s for n, s in clients.items() if n != exclude]
    for s in targets:
        send(s, text)


def choose_nickname(conn, reader):
    """Ask for a nickname until a valid, unused one is given."""
    send(conn, "Enter a nickname:")
    for line in reader:
        name = line.strip()
        if not name or " " in name or len(name) > 16:
            send(conn, "Invalid nickname (1-16 chars, no spaces). Try again:")
            continue
        with lock:
            if name not in clients:
                clients[name] = conn
                return name
        send(conn, "That nickname is taken. Try another:")
    return None


def handle_command(nick, conn, msg):
    """Run a slash command. Returns False if the user wants to quit."""
    parts = msg.split(" ", 2)
    cmd = parts[0].lower()
    if cmd == "/quit":
        return False
    if cmd == "/help":
        send(conn, HELP)
    elif cmd == "/list":
        with lock:
            names = ", ".join(sorted(clients))
        send(conn, f"Online: {names}")
    elif cmd == "/msg":
        if len(parts) < 3:
            send(conn, "Usage: /msg <user> <text>")
        else:
            target, text = parts[1], parts[2]
            with lock:
                target_sock = clients.get(target)
            if target_sock is None:
                send(conn, f"No such user: {target}")
            else:
                send(target_sock, f"[private from {nick}] {text}")
                send(conn, f"[private to {target}] {text}")
    else:
        send(conn, "Unknown command. Type /help.")
    return True


def handle_client(conn, addr):
    reader = conn.makefile("r", encoding="utf-8", newline="\n")
    nick = None
    try:
        nick = choose_nickname(conn, reader)
        if nick is None:
            return
        logging.info("%s joined from %s:%s", nick, *addr)
        send(conn, f"Welcome, {nick}! Type /help for commands.")
        broadcast(f"* {nick} joined the chat", exclude=nick)
        for line in reader:
            msg = line.strip()
            if not msg:
                continue
            if msg.startswith("/"):
                if not handle_command(nick, conn, msg):
                    break
            else:
                logging.info("[%s] %s", nick, msg)
                broadcast(f"[{nick}] {msg}", exclude=nick)
    except (ConnectionResetError, UnicodeDecodeError):
        pass
    finally:
        if nick:
            with lock:
                clients.pop(nick, None)
            logging.info("%s left", nick)
            broadcast(f"* {nick} left the chat")
        conn.close()


def main():
    parser = argparse.ArgumentParser(description="Chat server")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()

    logging.basicConfig(
        filename="chat.log", level=logging.INFO, format="%(asctime)s %(message)s"
    )
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((args.host, args.port))
    server.listen()
    print(f"Server listening on {args.host}:{args.port} (Ctrl+C to stop)")
    try:
        while True:
            conn, addr = server.accept()
            threading.Thread(
                target=handle_client, args=(conn, addr), daemon=True
            ).start()
    except KeyboardInterrupt:
        print("\nShutting down.")
    finally:
        server.close()


if __name__ == "__main__":
    main()
