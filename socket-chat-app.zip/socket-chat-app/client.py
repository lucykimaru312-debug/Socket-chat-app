"""Command-line chat client. Run server.py first."""
import argparse
import socket
import sys
import threading


def receive(sock):
    """Print incoming lines until the server closes the connection."""
    try:
        for line in sock.makefile("r", encoding="utf-8", newline="\n"):
            print(line.rstrip("\n"))
    except OSError:
        pass
    print("Disconnected from server.")
    sock.close()


def main():
    parser = argparse.ArgumentParser(description="Chat client")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    args = parser.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        sock.connect((args.host, args.port))
    except OSError as e:
        sys.exit(f"Could not connect to {args.host}:{args.port} ({e})")

    t = threading.Thread(target=receive, args=(sock,), daemon=True)
    t.start()
    try:
        while t.is_alive():
            text = input()
            sock.sendall((text + "\n").encode("utf-8"))
            if text.strip().lower() == "/quit":
                break
    except (EOFError, KeyboardInterrupt, OSError):
        pass
    finally:
        try:
            sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        sock.close()


if __name__ == "__main__":
    main()
